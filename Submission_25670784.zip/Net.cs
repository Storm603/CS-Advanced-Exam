﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FishingNet
{
    public class Net
    {
        public List<Fish> Fish { get; set; }
        public string Material { get; set; }
        public int Capacity { get; set; }
        public int Count => Fish.Count;
        public Net(string material, int capacity)
        {
            Material = material;
            Capacity = capacity;
            Fish = new List<Fish>();
        }

        public string AddFish(Fish fish)
        {
            if (string.IsNullOrEmpty(fish.FishType) || fish.Length <= 0 || fish.Weight <= 0)
            {
                return "Invalid fish.";
            }
            if (Count >= Capacity)
            {
                return "Fishing net is full.";
            }

            this.Fish.Add(fish);
            return $"Successfully added {fish.FishType} to the fishing net.";

        }

        public bool ReleaseFish(double weight)
        {
            Fish fish = Fish.FirstOrDefault(x => x.Weight == weight);
            return Fish.Remove(fish);
        }

        public Fish GetFish(string fishType)
        {
            Fish fish = Fish.FirstOrDefault(x => x.FishType == fishType);
            return fish;
        }

        public Fish GetBiggestFish()
        {
            Fish fish = null;
            double biggestFish = 0;

            foreach (Fish fish1 in Fish)
            {
                if (fish1.Length > biggestFish)
                {
                    biggestFish = fish1.Length;
                    fish = fish1;
                }
            }

            return fish;
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Into the {Material}");

            foreach (Fish fish in Fish.OrderByDescending(x => x.Length))
            {
                sb.AppendLine(fish.ToString());
            }

            return sb.ToString().Trim();
        }
    }
}
